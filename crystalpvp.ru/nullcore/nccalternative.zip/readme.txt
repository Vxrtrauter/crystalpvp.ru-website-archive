NullCore cracked by mrnv @ PlutoSolutions
https://github.com/PlutoSolutions
https://t.me/plutosolutions

mrnv: https://github.com/mr-nv | https://t.me/ayywareseller

How to inject:
1. Inject nccsteam.dll into steam.exe ONCE (you only have to reinject it if you restart steam)
2. Open TF2, if everything went fine the game should start normally and not crash
3. While in the main menu, inject nccgame.dll into hl2.exe (the game)
4. If everything is fine the cheat should load, otherwise try again and/or create an issue on the github: https://github.com/PlutoSolutions/NullCore